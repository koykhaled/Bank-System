<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo notifyCss(); ?>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="<?php echo e(asset('assets/favicon.ico')); ?>" type="image/x-icon" />
    <link rel="stylesheet" href="<?php echo e(asset('css/dashboard/style.css')); ?>" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>

<body>

    <div class="main">
        <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('index'); ?>
        <?php echo $__env->yieldContent('topics'); ?>
        <?php echo $__env->yieldContent('create_topics'); ?>
    </div>
    <div class="container">
        <?php echo $__env->make('admin.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>



    <script src="<?php echo e(asset('js/dashboard/main.js')); ?>"></script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <?php echo notifyJs(); ?>
</body>

</html>
<?php /**PATH C:\laragon\www\BankSys\resources\views/layouts/app.blade.php ENDPATH**/ ?>