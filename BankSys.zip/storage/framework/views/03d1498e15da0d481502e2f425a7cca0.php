
<?php $__env->startSection('create_topics'); ?>
    <div class="cardBox">
        <div class="card">
            <div>
                <div class="cardName"><?php echo e($customer->name); ?></div>
                <div class="numbers"><?php echo e($customer->balance); ?> $</div>
            </div>
            <div class="iconBox">
                <ion-icon name="person-outline"></ion-icon>
            </div>
        </div>
    </div>
    <div class="layout__box">
        <div class="layout__boxHeader">
            <?php if (isset($component)) { $__componentOriginal58ef761b4a8d895ed279bb45cfc348ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal58ef761b4a8d895ed279bb45cfc348ea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'notify::components.notify','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('notify::notify'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal58ef761b4a8d895ed279bb45cfc348ea)): ?>
<?php $attributes = $__attributesOriginal58ef761b4a8d895ed279bb45cfc348ea; ?>
<?php unset($__attributesOriginal58ef761b4a8d895ed279bb45cfc348ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal58ef761b4a8d895ed279bb45cfc348ea)): ?>
<?php $component = $__componentOriginal58ef761b4a8d895ed279bb45cfc348ea; ?>
<?php unset($__componentOriginal58ef761b4a8d895ed279bb45cfc348ea); ?>
<?php endif; ?>
            <div class="layout__boxTitle">
                <a href="<?php echo e(route('customers.index')); ?>">
                    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="32" height="32"
                        viewBox="0 0 32 32">
                        <title>arrow-left</title>
                        <path
                            d="M13.723 2.286l-13.723 13.714 13.719 13.714 1.616-1.611-10.96-10.96h27.625v-2.286h-27.625l10.965-10.965-1.616-1.607z">
                        </path>
                    </svg>
                </a>

                <h3><?php echo e($customer->name); ?></h3>
                <h3><?php echo e($customer->balance); ?>$</h3>
            </div>
        </div>
        <div class="layout__body">
            <form class="form" action="<?php echo e(route('customers.transfares', $customer->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="form__group">
                    <select id="cateories" name="customer">

                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($customer->id); ?>">
                                <?php echo e($customer->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                </div>

                <div class="form__group">
                    <label for="to_customer">Amount</label>
                    <input required type="number" name="amount" />
                </div>

                <div class="form__action">
                    <a class="btn btn--dark" href="<?php echo e(route('customers.index')); ?>">Cancel</a>
                    <button class="btn btn--main" type="submit">Send</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\BankSys\resources\views/admin/customers/show.blade.php ENDPATH**/ ?>