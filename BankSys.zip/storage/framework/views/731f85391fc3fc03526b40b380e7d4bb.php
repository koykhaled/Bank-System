<div class="topbar">
    <div class="toggle">
        <ion-icon name="menu-outline"></ion-icon>
    </div>
</div><?php /**PATH C:\laragon\www\BankSys\resources\views/admin/navbar.blade.php ENDPATH**/ ?>