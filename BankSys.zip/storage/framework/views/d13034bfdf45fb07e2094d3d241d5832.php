<div class="navigation">
    <ul>
        <li>
            <a href="" class="header__logo">
                <img src="<?php echo e(asset('assets/logo.svg')); ?>" />
                <h2>BankSys</h2>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('home')); ?>">
                <span class="icon">
                    <ion-icon name="home-outline"></ion-icon>
                </span>
                <span class="title">Home</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('customers.index')); ?>">
                <span class="icon">
                    <ion-icon name="person-outline"></ion-icon>
                </span>
                <span class="title">Customers</span>
            </a>
        </li>
    </ul>
</div><?php /**PATH C:\laragon\www\BankSys\resources\views/admin/navigation.blade.php ENDPATH**/ ?>