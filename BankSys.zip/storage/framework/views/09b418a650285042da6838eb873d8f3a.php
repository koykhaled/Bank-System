    <div class="cardBox">
        <div class="card">
            <div>
                <?php if($customers == 0): ?>
                    <div class="cardName">No Customers</div>
                <?php elseif($customers > 1): ?>
                    <div class="numbers"><?php echo e($customers); ?></div>
                    <div class="cardName">Customers</div>
                <?php else: ?>
                    <div class="numbers"><?php echo e($customers); ?></div>
                    <div class="cardName">Customer</div>
                <?php endif; ?>
            </div>
            <div class="iconBox">
                <ion-icon name="person-outline"></ion-icon>
            </div>
        </div>
    </div>
<?php /**PATH C:\laragon\www\BankSys\resources\views/admin/main.blade.php ENDPATH**/ ?>