@extends('layouts.app')
@section('title')
    Home
@endsection

@section('index')
    @include('admin.main')
@endsection
